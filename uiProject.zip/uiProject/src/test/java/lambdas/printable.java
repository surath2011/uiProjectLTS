package lambdas;
@FunctionalInterface
public interface printable {
     abstract String print(String suffix) ;
}
